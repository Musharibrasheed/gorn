<?php $__env->startSection('page-title'); ?>
    <?php echo isset($pageContent->meta_title) ? $pageContent->meta_title : meta_title(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-keywords'); ?>
    <?php echo isset($pageContent->meta_keywords) ? $pageContent->meta_keywords : meta_keywords(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-description'); ?>
    <?php echo isset($pageContent->meta_description) ? $pageContent->meta_description : meta_description(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('body-class'); ?> acc-dt <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- pageheader  -->
<!-- ============================================================== -->
<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="page-header">
            <h2 class="pageheader-title">Dashboard</h2>
            
            <div class="page-breadcrumb">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin_dashboard')); ?>" class="breadcrumb-link">Dashboard</a></li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- end pageheader  -->

<div class="ecommerce-widget" style="height:900px">

    <div class="row">
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
         
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
            
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
            
        </div>
        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 col-12">
            
        </div>
    </div>
    <div class="row">
        <!-- ============================================================== -->

        <!-- ============================================================== -->

        <!-- recent orders  -->
        <!-- ============================================================== -->
        <div class="col-xl-12 col-lg-12 col-md-6 col-sm-12 col-12">
            
        </div>
        <!-- ============================================================== -->
        <!-- end recent orders  -->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/appearls/public_html/dev/appear/resources/views/admin/dashboard/index.blade.php ENDPATH**/ ?>