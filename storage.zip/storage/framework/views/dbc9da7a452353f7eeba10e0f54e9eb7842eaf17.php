                    </div>
                </div>
                <div class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                Copyright © <?php echo e(date('Y')); ?> . All rights reserved. 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" name="base_url" id="base_url" value="<?php echo e(URL::to('/')); ?>">
        <script src="<?php echo e(asset('admin_assets/vendor/jquery/jquery-3.3.1.min.js')); ?>"></script>
        <!-- bootstap bundle js -->
        <script src="<?php echo e(asset('admin_assets/vendor/bootstrap/js/bootstrap.bundle.js')); ?>"></script>
        <!-- slimscroll js -->
        <script src="<?php echo e(asset('admin_assets/vendor/slimscroll/jquery.slimscroll.js')); ?>"></script>
        <!-- main js -->
        <script src="<?php echo e(asset('admin_assets/libs/js/main-js.js')); ?>"></script>


        <?php if(Route::currentRouteName() == 'admin_dashboard'): ?>
            <!-- sparkline js -->
            <script src="<?php echo e(asset('admin_assets/vendor/charts/sparkline/jquery.sparkline.js')); ?>"></script>

            <script src="<?php echo e(asset('admin_assets/libs/js/dashboard-ecommerce.js')); ?>"></script>

        <?php endif; ?>
        <?php echo $__env->yieldContent('footer_script'); ?>
    </body>

</html>
<?php /**PATH /home2/appearls/public_html/dev/appear/resources/views/admin/footer.blade.php ENDPATH**/ ?>