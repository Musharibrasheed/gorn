<?php $__env->startSection('page-title'); ?>
    <?php echo isset($pageContent->meta_title) ? $pageContent->meta_title : 'Link Meeting'; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-keywords'); ?>
    <?php echo isset($pageContent->meta_keywords) ? $pageContent->meta_keywords : 'Link Meeting'; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-description'); ?>
    <?php echo isset($pageContent->meta_description) ? $pageContent->meta_description : 'Link Meeting'; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-scripts'); ?>
    <link href="<?php echo e(asset('tinymce/skins/lightgray/skin.min.css')); ?>" type="text/css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body-class'); ?> acc-dt <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<section class="content-area">
        <div class="container-fluid full-ht">
            <div class="ptpx-30 pbpx-30">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="styled-head">
                            <h2>Update Page</h2>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">

                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <div class="error">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <?php if(session()->has('success')): ?>
                                <div class="alert alert-success alert-dismissable custom-success-box" style="margin: 15px;">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php if(is_array(session()->get('success'))): ?>
                                        <ul>
                                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($message); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <?php echo e(session()->get('success')); ?>

                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>


                            <form action="<?php echo e(route('admin_page_update_post',['id'=>$page->id])); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                            <div class="col-sm-8"><!-- col-xl-8 -->

                                <div class="row form-group">
                                    <div class="col-sm-12">
                                        <div class="field">
                                            <label>Page Title</label>
                                            <input type="text" value="<?php echo e(old('title',$pageDescription->title ?? '')); ?>" name="title" placeholder="Page title here... (Eg: Home Page)" class="form-control form-control-lg">
                                        </div>
                                    </div>
                                </div>

                                <div class="row custom_url form-group" >
                                    <div class="col-sm-12">
                                        <div class="field">
                                            <label>Short Title</label>
                                            <input type="text" value="<?php echo e(old('title',$pageDescription->short_title ?? '')); ?>" name="short_title" placeholder="Page short title here... (Eg: Home)" class="form-control form-control-lg" />
                                        </div>
                                    </div>
                                </div>

                                <div class="row pages form-group" >
                                    <div class="col-sm-12">
                                        <div class="field">
                                            <label>Page Content 1</label>
                                            <textarea rows="10" name="content" class="form-control form-control-lg my-editor"><?php echo e(old('title',$pageDescription->content ?? '')); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                 
                                
                                <div class="row">
                                    <div class="col-sm-12">                               
                                        <div class="field">
                                            <label>Page Video (Youtube Embeded URL like: https://www.youtube.com/embed/3h-1h168Blo)</label>
                                            <input type="text" value="<?php echo e(old('title',$pageDescription->page_video ?? '')); ?>" name="page_video" placeholder="https://www.youtube.com/embed/3h-1h168Blo" class="form-control form-control-lg" />
                                        </div>
                                    </div>
                                </div>

                                <div class="row hometemplate template_attributes">
                                    <div class="col-sm-12 form-group">
                                        <h3>Section 1</h3>
                                        <div class="field">
                                            <label>About GORN</label>
                                            <input type="text" value="<?php echo e(old('about_gorn_heading',$page_meta['about_gorn_heading'] ?? '')); ?>" name="about_gorn_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="field">
                                            <label>Text</label>
                                            <textarea rows="10" name="about_gorn_text" class="form-control form-control-lg my-editor"><?php echo e(old('title',$page_meta['about_gorn_text'] ?? '')); ?></textarea>
                                        </div>
                                    </div>

                                    <div class="col-sm-12">
                                        <h3>Section 2</h3>                        
                                        <div class="field">
                                            <label>Heading</label>
                                            <input type="text" value="<?php echo e(old('section2_heading',$page_meta['section2_heading'] ?? '')); ?>" name="section2_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 1</label>
                                            <input type="text" value="<?php echo e(old('section2_bx1_heading',$page_meta['section2_bx1_heading'] ?? '')); ?>" name="section2_bx1_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="10" name="section2_bx1_text" class="form-control form-control-lg my-editor"><?php echo e(old('title',$page_meta['section2_bx1_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 2</label>
                                            <input type="text" value="<?php echo e(old('section2_bx2_heading',$page_meta['section2_bx2_heading'] ?? '')); ?>" name="section2_bx2_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="section2_bx2_text" class="form-control form-control-lg my-editor"><?php echo e(old('title',$page_meta['section2_bx2_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 3</label>
                                            <input type="text" value="<?php echo e(old('section2_bx3_heading',$page_meta['section2_bx3_heading'] ?? '')); ?>" name="section2_bx3_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="section2_bx3_text" class="form-control form-control-lg my-editor"><?php echo e(old('title',$page_meta['section2_bx3_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12">
                                        <h3>Section 3</h3> 
                                        <div class="field">
                                            <input type="text" value="<?php echo e(old('section3_heading',$page_meta['section3_heading'] ?? '')); ?>" name="section3_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="10" name="section3_text" class="form-control form-control-lg my-editor"><?php echo e(old('title',$page_meta['section3_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>
                                    
                                </div>

                                <!-- healthcare professionals -->
                                <div class="row healthcare-professionalstemplate template_attributes">
                                    <div class="col-sm-12 form-group">
                                        <h3>Section 1</h3>
                                        <div class="field">
                                            <input type="text" value="<?php echo e(old('hc_sec1_heading',$page_meta['hc_sec1_heading'] ?? '')); ?>" name="hc_sec1_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                                        <div class="field">
                                            <label>Text</label>
                                            <textarea rows="10" name="hc_sec1_text" class="form-control form-control-lg my-editor"><?php echo e(old('title',$page_meta['hc_sec1_text'] ?? '')); ?></textarea>
                                        </div>
                                    </div>

                                    <div class="col-sm-12">
                                        <h3>Section 2</h3>                        
                                        <div class="field">
                                            <label>Tag Line</label>
                                            <input type="text" value="<?php echo e(old('hc_sec2_tagline',$page_meta['hc_sec2_tagline'] ?? '')); ?>" name="hc_sec2_tagline" placeholder="Heading..." class="form-control form-control-lg" />
                                        </div>                              
                                        <div class="field">
                                            <label>Heading</label>
                                            <input type="text" value="<?php echo e(old('hc_sec2_heading',$page_meta['hc_sec2_heading'] ?? '')); ?>" name="hc_sec2_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="10" name="hc_sec2_text" class="form-control form-control-lg my-editor"><?php echo e(old('title',$page_meta['hc_sec2_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12">
                                        <h3>Section 3</h3> 
                                        <div class="field">
                                            <input type="text" value="<?php echo e(old('hc_sec3_heading',$page_meta['hc_sec3_heading'] ?? '')); ?>" name="hc_sec3_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="10" name="hc_sec3_text" class="form-control form-control-lg my-editor"><?php echo e(old('title',$page_meta['hc_sec3_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <!-- ss -->
                                    <div class="col-sm-12">
                                        <h3>Section 4</h3>  
                                        <div class="field">
                                            <label>Tag Line</label>
                                            <input type="text" value="<?php echo e(old('hc_sec4_tagline',$page_meta['hc_sec4_tagline'] ?? '')); ?>" name="hc_sec4_tagline" placeholder="Tag Line" class="form-control form-control-lg" />
                                        </div>

                                        <div class="field">
                                            <label>Heading</label>
                                            <input type="text" value="<?php echo e(old('hc_sec4_heading',$page_meta['hc_sec4_heading'] ?? '')); ?>" name="hc_sec4_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 1</label>
                                            <input type="text" value="<?php echo e(old('hc_sec4_bx1_heading',$page_meta['hc_sec4_bx1_heading'] ?? '')); ?>" name="hc_sec4_bx1_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="10" name="hc_sec4_bx1_text" class="form-control form-control-lg my-editor"><?php echo e(old('title',$page_meta['hc_sec4_bx1_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 2</label>
                                            <input type="text" value="<?php echo e(old('hc_sec4_bx2_heading',$page_meta['hc_sec4_bx2_heading'] ?? '')); ?>" name="hc_sec4_bx2_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="hc_sec4_bx2_text" class="form-control form-control-lg my-editor"><?php echo e(old('title',$page_meta['hc_sec4_bx2_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 3</label>
                                            <input type="text" value="<?php echo e(old('hc_sec4_bx3_heading',$page_meta['hc_sec4_bx3_heading'] ?? '')); ?>" name="hc_sec4_bx3_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="hc_sec4_bx3_text" class="form-control form-control-lg my-editor"><?php echo e(old('title',$page_meta['hc_sec4_bx3_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>
                                    
                                </div>
                                <!-- healthcare professionals end-->



                                <!-- facilities -->
                                <div class="row facilitiestemplate template_attributes">
                                    <div class="col-sm-12">
                                        <h3>Section 1</h3>  
                                        <div class="field">
                                            <label>Tag Line</label>
                                            <input type="text" value="<?php echo e(old('fac_sec1_tagline',$page_meta['fac_sec1_tagline'] ?? '')); ?>" name="fac_sec1_tagline" placeholder="Tag Line" class="form-control form-control-lg" />
                                        </div>

                                        <div class="field">
                                            <label>Heading</label>
                                            <input type="text" value="<?php echo e(old('fac_sec1_heading',$page_meta['fac_sec1_heading'] ?? '')); ?>" name="fac_sec1_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 1</label>
                                            <input type="text" value="<?php echo e(old('fac_sec1_bx1_heading',$page_meta['fac_sec1_bx1_heading'] ?? '')); ?>" name="fac_sec1_bx1_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="10" name="fac_sec1_bx1_text" class="form-control form-control-lg my-editor"><?php echo e(old('fac_sec1_bx1_text',$page_meta['fac_sec1_bx1_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 2</label>
                                            <input type="text" value="<?php echo e(old('fac_sec1_bx2_heading',$page_meta['fac_sec1_bx2_heading'] ?? '')); ?>" name="fac_sec1_bx2_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="fac_sec1_bx2_text" class="form-control form-control-lg my-editor"><?php echo e(old('fac_sec1_bx2_text',$page_meta['fac_sec1_bx2_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 3</label>
                                            <input type="text" value="<?php echo e(old('fac_sec1_bx3_heading',$page_meta['fac_sec1_bx3_heading'] ?? '')); ?>" name="fac_sec1_bx3_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="fac_sec1_bx3_text" class="form-control form-control-lg my-editor"><?php echo e(old('fac_sec1_bx3_text',$page_meta['fac_sec1_bx3_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>
                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 4</label>
                                            <input type="text" value="<?php echo e(old('fac_sec1_bx4_heading',$page_meta['fac_sec1_bx4_heading'] ?? '')); ?>" name="fac_sec1_bx4_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="fac_sec1_bx4_text" class="form-control form-control-lg my-editor"><?php echo e(old('fac_sec1_bx4_text',$page_meta['fac_sec1_bx4_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>
                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 5</label>
                                            <input type="text" value="<?php echo e(old('fac_sec1_bx5_heading',$page_meta['fac_sec1_bx5_heading'] ?? '')); ?>" name="fac_sec1_bx5_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="fac_sec1_bx5_text" class="form-control form-control-lg my-editor"><?php echo e(old('fac_sec1_bx5_text',$page_meta['fac_sec1_bx5_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>
                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 6</label>
                                            <input type="text" value="<?php echo e(old('fac_sec1_bx6_heading',$page_meta['fac_sec1_bx6_heading'] ?? '')); ?>" name="fac_sec1_bx6_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="fac_sec1_bx6_text" class="form-control form-control-lg my-editor"><?php echo e(old('fac_sec1_bx6_text',$page_meta['fac_sec1_bx6_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>
                                    <!-- section 2 -->
                                    <div class="col-sm-12"> 
                              
                                        <div class="field">
                                            <label>Section 2</label>
                                            <input type="text" value="<?php echo e(old('fac_sec2_heading',$page_meta['fac_sec2_heading'] ?? '')); ?>" name="fac_sec2_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="fac_sec2_text" class="form-control form-control-lg my-editor"><?php echo e(old('fac_sec2_text',$page_meta['fac_sec2_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <!-- section 3 -->
                                    <div class="col-sm-12"> 
                              
                                        <div class="field">
                                            <label>Section 3</label>
                                            <textarea rows="5" name="fac_sec3_text" class="form-control form-control-lg my-editor"><?php echo e(old('fac_sec3_text',$page_meta['fac_sec3_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <!-- section 4 -->
                                    <div class="col-sm-12"> 
                                       
                                        <div class="field">
                                            <label>Section 4</label>
                                            <input type="text" value="<?php echo e(old('fac_sec4_heading',$page_meta['fac_sec4_heading'] ?? '')); ?>" name="fac_sec4_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="fac_sec4_text" class="form-control form-control-lg my-editor"><?php echo e(old('fac_sec4_text',$page_meta['fac_sec4_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <!-- section 5 -->
                                    <div class="col-sm-12"> 
                                       
                                        <div class="field">
                                        <label>Section 5</label>
                                        <input type="text" value="<?php echo e(old('fac_sec5_heading',$page_meta['fac_sec5_heading'] ?? '')); ?>" name="fac_sec5_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                
                                        </div>
                                    </div>
                                    
                                </div>

                                <!-- facilities end -->

                                <!-- staffing -->
                                <div class="row staffingtemplate template_attributes">
                                    <div class="col-sm-12">
                                        <h3>Section 1</h3>  
                                        

                                        <div class="field">
                                            <label>Heading</label>
                                            <input type="text" value="<?php echo e(old('staff_sec1_heading',$page_meta['staff_sec1_heading'] ?? '')); ?>" name="staff_sec1_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                        </div>
                                    </div>
                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 1</label>
                                            <input type="text" value="<?php echo e(old('staff_sec1_bx1_heading',$page_meta['staff_sec1_bx1_heading'] ?? '')); ?>" name="staff_sec1_bx1_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="10" name="staff_sec1_bx1_text" class="form-control form-control-lg my-editor"><?php echo e(old('staff_sec1_bx1_text',$page_meta['staff_sec1_bx1_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 2</label>
                                            <input type="text" value="<?php echo e(old('staff_sec1_bx2_heading',$page_meta['staff_sec1_bx2_heading'] ?? '')); ?>" name="staff_sec1_bx2_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="staff_sec1_bx2_text" class="form-control form-control-lg my-editor"><?php echo e(old('staff_sec1_bx2_text',$page_meta['staff_sec1_bx2_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 3</label>
                                            <input type="text" value="<?php echo e(old('staff_sec1_bx3_heading',$page_meta['staff_sec1_bx3_heading'] ?? '')); ?>" name="staff_sec1_bx3_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="staff_sec1_bx3_text" class="form-control form-control-lg my-editor"><?php echo e(old('staff_sec1_bx3_text',$page_meta['staff_sec1_bx3_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12"> 
                                       
                                        <h3>Section 2</h3>  
                                        <div class="field">
                                            <label>Box 1</label>
                                            <input type="text" value="<?php echo e(old('staff_sec2_bx1_heading',$page_meta['staff_sec2_bx1_heading'] ?? '')); ?>" name="staff_sec2_bx1_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="staff_sec2_bx1_text" class="form-control form-control-lg my-editor"><?php echo e(old('staff_sec2_bx1_text',$page_meta['staff_sec2_bx1_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12">
                              
                                        <div class="field">
                                            <label>Box 2</label>
                                            <input type="text" value="<?php echo e(old('staff_sec2_bx2_heading',$page_meta['staff_sec2_bx2_heading'] ?? '')); ?>" name="staff_sec2_bx2_heading" placeholder="Heading..." class="form-control form-control-lg" />
                                            <textarea rows="5" name="staff_sec2_bx2_text" class="form-control form-control-lg my-editor"><?php echo e(old('staff_sec2_bx2_text',$page_meta['staff_sec2_bx2_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12"> 
                                       
                                        <h3>Section 3</h3>  
                                        <div class="field">                                            
                                            <textarea rows="5" name="staff_sec3_text" class="form-control form-control-lg my-editor"><?php echo e(old('staff_sec3_text',$page_meta['staff_sec3_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                    <div class="col-sm-12"> 
                                       
                                        <h3>Section 4</h3>  
                                        <div class="field">                                            
                                            <textarea rows="5" name="staff_sec4_text" class="form-control form-control-lg my-editor"><?php echo e(old('staff_sec4_text',$page_meta['staff_sec4_text'] ?? '')); ?></textarea>
                                        </div>
                                
                                    </div>

                                </div>
                                <!-- staffing end -->
                                
                                
                                <div class="row field form-group">
                                    <div class="col-sm-3">
                                        <a href="<?php echo e(route('admin_pages')); ?>" class="btn btn-block btn-primary">Cancel</a>
                                    </div>
                                    <div class="col-sm-3">
                                       <input type="submit" class="btn btn-block btn-primary" value="Update">
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="row">
                                    
                                    <div class="col-sm-12">
                                        <div class="upload-bx">
                                            <div class="field file_manager_field">
                                                <h4>Image</h4>
                                                <label>Page Image</label>
                                                <input type="text" id="thumbnail" name="page_image" value="<?php echo e(old('page_image',(isset($page->image) ? asset($page->image) : '') )); ?>" class="form-control form-control-lg" />
                                                <i class="fa fa-image" aria-hidden="true" id="lfm" data-input="thumbnail" data-preview="holder"></i>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <div class="field">
                                            <h4>Page Attribute</h4>
                                            <label>Template</label></br></br>                                                
                                                <select name="template" class="template_trigger file_manager_field form-control form-control-lg">
                                                    <option value="">Select Template</option>
                                                    <?php if(!empty(getTemplates())): ?>
                                                        <?php $__currentLoopData = getTemplates(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($name); ?>" <?php if( old('template',$pageDescription->template ?? '') == $name ): ?> selected="" <?php endif; ?>><?php echo e($template); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-12">
                                        <div class="form-group">
                                        <label>Status</label>
                                            <div class="field mbpx-35">
                                                <select name="status" class="form-control form-control-lg">
                                                    <option value="">Select Status</option>
                                                    <option value="Active" <?php if( old('status',$page->status ?? '') == 'Active' ): ?> selected="" <?php endif; ?>>Active</option>
                                                    <option value="Inactive" <?php if( old('status',$page->status ?? '') == 'Inactive' ): ?> selected="" <?php endif; ?>>Inactive</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <h4>SEO (Optional)</h4>
                                            <div class="field">
                                            <label>Meta Title</label>
                                            <input type="text" name="meta_title" value="<?php echo e(old('meta_title',$pageDescription->meta_title ?? '')); ?>" class="form-control form-control-lg">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <div class="field">
                                                <label>Meta Keywords</label>
                                                <input type="text" name="meta_keywords" value="<?php echo e(old('meta_keywords',$pageDescription->meta_keywords ?? '')); ?>" class="form-control form-control-lg">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <div class="field">
                                                <label>Meta Description</label>
                                                <input type="text" name="meta_description" value="<?php echo e(old('meta_description',$pageDescription->meta_description ?? '')); ?>" class="form-control form-control-lg">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-12">
                                        <div class="field">
                                            <h4>Social Setting</h4>
                                            <input type="checkbox" name="social_links"  <?php if( $page->social_links == 1 ): ?> checked <?php endif; ?> value="1" class="form-control-lg" />
                                             <span>Social Links </span>
                                             <input type="checkbox" name="newsletter" <?php if( $page->newsletter == 1 ): ?> checked <?php endif; ?> value="1" class="form-control-lg" />
                                             <span>Newsletter </span>
                                        </div>
                                    </div>

                                </div><!-- show-amm mbpx-20 -->
                            </div>
                        </div>
                    </div><!-- col-xl-4 rht-sd -->
                </div>

                            </form>

                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer_script'); ?>
    <style>
        .template_attributes
        {
            display:none;
        }
    </style>
    <script src="<?php echo e(asset('/tinymce/tinymce_new.min.js')); ?>"></script>
    <script>
        var editor_config = {
            path_absolute : "<?php echo e(url('/')); ?>/",
            selector: "textarea.my-editor",
            plugins: [
                "advlist autolink lists link image charmap print preview hr anchor pagebreak",
                "searchreplace wordcount visualblocks visualchars code fullscreen",
                "insertdatetime media nonbreaking save table contextmenu directionality",
                "emoticons template paste textcolor colorpicker textpattern"
            ],
            toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media",
            relative_urls: false,
            templates: [{
                title: 'Test template 1',
                content: 'Test 1'
            }, {
                title: 'Test template 2',
                content: 'Test 2'
            }],
            file_browser_callback : function(field_name, url, type, win) {
                var x = window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName('body')[0].clientWidth;
                var y = window.innerHeight|| document.documentElement.clientHeight|| document.getElementsByTagName('body')[0].clientHeight;

                var cmsURL = editor_config.path_absolute + 'laravel-filemanager?field_name=' + field_name;
                if (type == 'image') {
                    cmsURL = cmsURL + "&type=Images";
                } else {
                    cmsURL = cmsURL + "&type=Files";
                }

                tinyMCE.activeEditor.windowManager.open({
                    file : cmsURL,
                    title : 'Filemanager',
                    width : x * 0.8,
                    height : y * 0.8,
                    resizable : "yes",
                    close_previous : "no"
                });
            },
        };

        tinymce.init(editor_config);
    </script>

    <script src="<?php echo e(asset('vendor/laravel-filemanager/js/stand-alone-button.js')); ?>"></script>
    <script>
        var route_prefix = "<?php echo e(url('laravel-filemanager')); ?>";        
        $('#lfm').filemanager('image', {prefix: route_prefix});

        $(document).ready(function(){
            $('.template_attributes').hide();
            var check_template = $('.template_trigger').val();
            
            if(check_template)
            {
                var template_class          = '.'+check_template + 'template';
                console.log(template_class);
                var template_attributes     = $( template_class ).length;
                if(template_attributes)
                {
                    $(template_class).show();
                }
            }

            $('.template_trigger').on('change',function(){

                var template                = $(this).val();
                var template_class          = '.'+template + 'template';
                var template_attributes     = $( template_class ).length;

                $('.template_attributes').hide();

                if(template_attributes)
                {
                    $(template_class).show();
                }

            })
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/appearls/public_html/dev/appear/resources/views/admin/page/edit.blade.php ENDPATH**/ ?>