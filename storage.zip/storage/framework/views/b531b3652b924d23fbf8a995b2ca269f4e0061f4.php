<?php $__env->startSection('page-title'); ?>
    <?php echo isset($pageContent->meta_title) ? $pageContent->meta_title : meta_title(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-keywords'); ?>
    <?php echo isset($pageContent->meta_keywords) ? $pageContent->meta_keywords : meta_keywords(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-description'); ?>
    <?php echo isset($pageContent->meta_description) ? $pageContent->meta_description : meta_description(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('body-class'); ?> inner-page <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<link rel="stylesheet" type="text/css" href="<?php echo e(URL::to('/')); ?>/css/app.css">
<section>

	<div class="breadcrumbs">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<span>
						<a href="<?php echo URL::to('/'); ?>">Home</a>
					</span>
					<span>
						<i class="fa fa-angle-right"></i>
					</span>
					<span>
						<a href="<?php echo URL::to('/'); ?>">Login</a>
					</span>
				</div>
			</div>
		</div>
	</div>


	<div class="container ptpx-66 pbpx-66 contact-pg-sec login-func">

		<div class="row">
			<div class="col-sm-5">

				<div class="hide-login">

					<h3 class="main-heading">Login</h3>

                    <form method="POST" action="<?php echo e(route('login_post')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="field">
                                        <input type="email" name="email" placeholder="Email" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="field">
                                        <input type="password" name="password" placeholder="Password" />
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="field">
                                        <label>
                                            <input type="checkbox" name="remember_me" value="1" />
                                            Remember Me
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <input type="submit" value="Login" name="" class="primary-btn blue lg">
                                </div>
                                <div class="col-sm-6 text-right">
                                    <a href="javascript:;" class="fgt-pass">Forgot Password?</a>
                                </div>
                            </div>
                        </div>
                    </form>
				</div>

				<div class="show-fg">
					<h3 class="main-heading">Forgot Password</h3>
					<div class="form">
						<div class="row">
							<div class="col-sm-12">
								<div class="field">
									<input type="email" name="" placeholder="Email">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6">
								<input type="submit" value="Send Email" name="" class="primary-btn blue lg">
							</div>
							<div class="col-sm-6 text-right">
								<a href="javascript:;" class="fgt-pass-login">Back to Login</a>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-sm-6 offset-sm-1">
				
				<div class="row">
                    <div class="col-12">
                        <?php if(session('message')): ?>
                            <div>   <div class="alert alert-success" ><?php echo session('message'); ?></div> </div>
                        <?php endif; ?>

                        <?php if($errors->has('first_name')): ?>
							<div class="field alert alert-danger">
								<?php echo $errors->first('first_name', '<span class="help-block">:message</span> '); ?>

							</div>
						<?php endif; ?>

						<?php if($errors->has('email')): ?>
							<div class="field alert alert-danger">
								<?php echo $errors->first('email', '<span class="help-block">:message</span> '); ?>

							</div>
						<?php endif; ?>

						<?php if($errors->has('account_type')): ?>
							<div class="field alert alert-danger">
								<?php echo $errors->first('account_type', '<span class="help-block">:message</span> '); ?>

							</div>
						<?php endif; ?>

						<?php if($errors->has('password')): ?>
							<div class="field alert alert-danger">
								<?php echo $errors->first('password', '<span class="help-block">:message</span> '); ?>

							</div>
						<?php endif; ?>

						<?php if($errors->has('confirm_password')): ?>
							<div class="field alert alert-danger">
								<?php echo $errors->first('confirm_password', '<span class="help-block">:message</span> '); ?>

							</div>
						<?php endif; ?>

                        
                    </div>
                </div>

				
			</div>
		</div>



	</div>


</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>
<script type="text/javascript">

	var inputLocalFiles = document.getElementById("thumbnail");
    inputLocalFiles.addEventListener("change", previewImages, false);
    function previewImages() {
        $('.image-preview').empty();
        var fileList = this.files;
        var anyWindow = window.URL || window.webkitURL;
        for (var i = 0; i < fileList.length; i++) {
            var j = i + 1;
            var objectUrl = anyWindow.createObjectURL(fileList[i]);
            $('.image-preview').html('<div class="image-preview-' + j + '"><img src="' + objectUrl + '" width="80%"></div>');
            //$('.image-preview-' + j).css({ 'background-image' : 'url(' + objectUrl + ')', 'background-size' : 'cover', 'background-repeat' : 'no-repeat', 'background-position' : 'center center' });
            window.URL.revokeObjectURL(fileList[i]);
        }
    }

	$("#mcountry").change(function(){
        var selectedCountry = $("#mcountry option:selected").val();
        $('#mstates').html("");
        $('#mcities').html("");
        var option=$('<option />');option.attr('value','').text('Select City');$('#mcities').append(option);
        var option=$('<option />');option.attr('value','').text('Please Wait');$('#mstates').append(option);
	    $.ajax({
	        type: "GET",
	         contentType: "application/json",
	        url: $('#base_url').val()+"/get-states/"+selectedCountry,
	    }).done(function(data){
	        $('#mstates').find("option:eq(0)").html("Select State");
	        $.each(data,function(key,val){
	            var option=$('<option />');option.attr('value',val.id).text(val.name);$('#mstates').append(option);
	        });
	        
	    });    
	});

	$("#mstates").change(function(){
	        var selectedState = $("#mstates option:selected").val();
	        $('#mcities').html("");
	        var option=$('<option />');option.attr('value','').text('Please Wait');$('#mcities').append(option);
		    $.ajax({
		        type: "GET",
		        crossDomain: true,
		        url: $('#base_url').val()+"/get-cities/"+selectedState,
		    }).done(function(data){	        
	        $('#mcities').find("option:eq(0)").html("Select City");
	        $.each(data,function(key,val){
	            var option=$('<option />');option.attr('value',key).text(val);$('#mcities').append(option);
	        });	        
	    });	    
	});

	function init() {
    	var input = document.getElementById('locationTextField');
    	if(input)
        	var autocomplete = new google.maps.places.Autocomplete(input);
	}

	google.maps.event.addDomListener(window, 'load', init);

</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBTP-IepVY7ysKJHH-os3kUp71bWdd509k&libraries=places&callback=init"></script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/appearls/public_html/dev/appear/resources/views/frontend/template/login.blade.php ENDPATH**/ ?>