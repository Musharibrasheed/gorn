<?php $__env->startSection('page-title'); ?>
    <?php echo isset($pageContent->meta_title) ? $pageContent->meta_title : 'Link Meeting'; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-keywords'); ?>
    <?php echo isset($pageContent->meta_keywords) ? $pageContent->meta_keywords : 'Link Meeting'; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta-description'); ?>
    <?php echo isset($pageContent->meta_description) ? $pageContent->meta_description : 'Link Meeting'; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('header-scripts'); ?>
    <link href="<?php echo e(asset('tinymce/skins/lightgray/skin.min.css')); ?>" type="text/css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body-class'); ?> acc-dt <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<section class="content-area">
        <div class="container-fluid full-ht">
            <div class="ptpx-30 pbpx-30">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="styled-head">
                            <h2>Add Page</h2>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-12">

                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <div class="error">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>

                            <?php if(session()->has('success')): ?>
                                <div class="alert alert-success alert-dismissable custom-success-box" style="margin: 15px;">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php if(is_array(session()->get('success'))): ?>
                                        <ul>
                                            <?php $__currentLoopData = session()->get('success'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($message); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php else: ?>
                                        <?php echo e(session()->get('success')); ?>

                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>


                            <form action="<?php echo e(route('admin_page_add_post')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                            <div class="col-sm-8"><!-- col-xl-8 -->

                                <div class="row form-group">
                                    <div class="col-sm-12">
                                        <div class="field">
                                            <label>Page Title</label>
                                            <input type="text" value="<?php echo e(old('title')); ?>" name="title" placeholder="Page title here... (Eg: Home Page)" class="form-control form-control-lg">
                                        </div>
                                    </div>
                                </div>

                                <div class="row custom_url form-group" >
                                    <div class="col-sm-12">
                                        <div class="field">
                                            <label>Short Title</label>
                                            <input type="text" value="<?php echo e(old('short_title')); ?>" name="short_title" placeholder="Page short title here... (Eg: Home)" class="form-control form-control-lg" />
                                        </div>
                                    </div>
                                </div>

                                <div class="row pages form-group" >
                                    <div class="col-sm-12">
                                        <div class="field">
                                            <label>Page Content 1</label>
                                            <textarea name="content" class="form-control form-control-lg my-editor"><?php echo e(old('content')); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                 

                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="field">
                                            <label>Page Video (Youtube Embeded URL like: https://www.youtube.com/embed/3h-1h168Blo)</label>
                                            <input type="text" value="<?php echo e(old('page_video')); ?>" name="page_video" placeholder="https://www.youtube.com/embed/3h-1h168Blo" class="form-control form-control-lg" />
                                        </div>
                                    </div>
                                </div>

                                <div class="row field form-group">
                                    <div class="col-sm-3">
                                        <a href="<?php echo e(route('admin_pages')); ?>" class="btn btn-block btn-primary">Cancel</a>
                                    </div>
                                    <div class="col-sm-3">
                                       <input type="submit" class="btn btn-block btn-primary" value="Add">
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-4">
                                <div class="row">

                                    
                                                                          <div class="col-sm-12">
                                            <div class="upload-bx">
                                                <div class="field file_manager_field">
                                                    <h4>Image</h4>
                                                    <label>Page Image</label>
                                                    <input type="text" id="thumbnail" name="page_image" value="<?php echo e(old('page_image')); ?>" class="form-control form-control-lg" />
                                                    <i class="fa fa-image" aria-hidden="true" id="lfm" data-input="thumbnail" data-preview="holder"></i>
                                                </div>
                                            </div>
                                        </div>
                                    
                                   

                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <div class="field">
                                            <h4>Page Attribute</h4>
                                            <label>Template</label></br></br>                                                
                                                <select name="template" class="form-control form-control-lg">
                                                    <option value="">Select Template</option>
                                                    <?php if(!empty(getTemplates())): ?>
                                                        <?php $__currentLoopData = getTemplates(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($name); ?>" <?php if( old('template') == $name ): ?> selected="" <?php endif; ?>><?php echo e($template); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-12">
                                        <div class="form-group">
                                        <label>Status</label>
                                            <div class="field mbpx-35">
                                                <select name="status" class="form-control form-control-lg">
                                                    <option value="">Select Status</option>
                                                    <option value="Active" <?php if( old('status') == 'Active' ): ?> selected="" <?php endif; ?>>Active</option>
                                                    <option value="Inactive" <?php if( old('status') == 'Inactive' ): ?> selected="" <?php endif; ?>>Inactive</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <h4>SEO (Optional)</h4>
                                            <div class="field">
                                                <label>Meta Title</label>
                                                <input type="text" name="meta_title" value="<?php echo e(old('meta_title')); ?>" class="form-control form-control-lg">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <div class="field">
                                                <label>Meta Keywords</label>
                                                <input type="text" name="meta_keywords" value="<?php echo e(old('meta_keywords')); ?>" class="form-control form-control-lg">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-sm-12">
                                        <div class="form-group">
                                            <div class="field">
                                                <label>Meta Description</label>
                                                <input type="text" name="meta_description" value="<?php echo e(old('meta_description')); ?>" class="form-control form-control-lg">
                                            </div>
                                        </div>
                                    </div>

                                </div><!-- show-amm mbpx-20 -->
                            </div>
                        </div>
                    </div><!-- col-xl-4 rht-sd -->
                </div>

                            </form>

                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer_script'); ?>
    <style>
        .template_attributes
        {
            display:none;
        }
    </style>
    <script src="<?php echo e(asset('/tinymce/tinymce_new.min.js')); ?>"></script>
    <script>
        var editor_config = {
            path_absolute : "<?php echo e(url('/')); ?>/",
            selector: "textarea.my-editor",
            plugins: [
                "advlist autolink lists link image charmap print preview hr anchor pagebreak",
                "searchreplace wordcount visualblocks visualchars code fullscreen",
                "insertdatetime media nonbreaking save table contextmenu directionality",
                "emoticons template paste textcolor colorpicker textpattern"
            ],
            toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media",
            relative_urls: false,
            templates: [{
                title: 'Test template 1',
                content: 'Test 1'
            }, {
                title: 'Test template 2',
                content: 'Test 2'
            }],
            file_browser_callback : function(field_name, url, type, win) {
                var x = window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName('body')[0].clientWidth;
                var y = window.innerHeight|| document.documentElement.clientHeight|| document.getElementsByTagName('body')[0].clientHeight;

                var cmsURL = editor_config.path_absolute + 'laravel-filemanager?field_name=' + field_name;
                if (type == 'image') {
                    cmsURL = cmsURL + "&type=Images";
                } else {
                    cmsURL = cmsURL + "&type=Files";
                }

                tinyMCE.activeEditor.windowManager.open({
                    file : cmsURL,
                    title : 'Filemanager',
                    width : x * 0.8,
                    height : y * 0.8,
                    resizable : "yes",
                    close_previous : "no"
                });
            },
        };

        tinymce.init(editor_config);
    </script>

    <script src="<?php echo e(asset('vendor/laravel-filemanager/js/stand-alone-button.js')); ?>"></script>
    <script>
        var route_prefix = "<?php echo e(url('laravel-filemanager')); ?>";
        
        $('#lfm').filemanager('image', {prefix: route_prefix});

        $(document).ready(function(){
            $('.template_attributes').hide();
            var check_template = $('.template_trigger').val();
            if(check_template)
            {
                var template_class          = '.'+check_template + 'template';
                var template_attributes     = $( template_class ).length;
                if(template_attributes)
                {
                    $(template_class).show();
                }
            }

            $('.template_trigger').on('change',function(){

                var template                = $(this).val();
                var template_class          = '.'+template + 'template';
                var template_attributes     = $( template_class ).length;

                $('.template_attributes').hide();

                if(template_attributes)
                {
                    $(template_class).show();
                }

            })
        })
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/appearls/public_html/dev/appear/resources/views/admin/page/add.blade.php ENDPATH**/ ?>